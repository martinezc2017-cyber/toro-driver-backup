// Legal documents for TORO DRIVER
// These documents are specific to drivers/contractors

class LegalDocuments {
  LegalDocuments._();

  static const String termsAndConditions = '''
================================================================================
TORO DRIVER - TERMS AND CONDITIONS OF SERVICE
Version 1.0 | Effective Date: January 2025
================================================================================

PLEASE READ THESE TERMS CAREFULLY BEFORE USING TORO DRIVER.

By accessing or using the Toro Driver application ("App"), you agree to be bound
by these Terms and Conditions ("Terms"). If you do not agree to these Terms,
do not use the App.

--------------------------------------------------------------------------------
1. ACCEPTANCE OF TERMS
--------------------------------------------------------------------------------

By creating an account, accessing, or using Toro Driver, you acknowledge that you
have read, understood, and agree to be bound by these Terms, our Privacy Policy,
Driver Agreement, and all applicable laws and regulations.

--------------------------------------------------------------------------------
2. DESCRIPTION OF SERVICE
--------------------------------------------------------------------------------

Toro Driver is a technology platform that connects independent third-party service
providers ("Drivers") with users seeking transportation and delivery services.

TORO DRIVER:
- Provides a technology platform to facilitate connections
- Does NOT employ Drivers - you are an independent contractor
- Does NOT control how you perform services
- Does NOT guarantee minimum earnings

--------------------------------------------------------------------------------
3. ELIGIBILITY REQUIREMENTS
--------------------------------------------------------------------------------

To use Toro Driver as a Driver, you must:
- Be at least 21 years of age
- Have a valid driver's license for at least 1 year
- Pass a background check and driving record review
- Have valid auto insurance meeting minimum requirements
- Have a vehicle that meets our safety and age requirements
- Have the legal right to work in your jurisdiction
- Maintain accurate and complete registration information

--------------------------------------------------------------------------------
4. DRIVER RESPONSIBILITIES
--------------------------------------------------------------------------------

As a Driver, you agree to:
- Provide safe, professional transportation services
- Maintain your vehicle in safe operating condition
- Comply with all traffic laws and regulations
- Maintain valid insurance and registration
- Complete services in a timely manner
- Treat riders and other users with respect
- Not use the service while impaired
- Keep your account information current

--------------------------------------------------------------------------------
5. INDEPENDENT CONTRACTOR STATUS
--------------------------------------------------------------------------------

YOU ACKNOWLEDGE AND AGREE THAT:
- You are an independent contractor, NOT an employee
- You control when, where, and how you provide services
- You can accept or decline any service request
- You can use other platforms simultaneously
- You are responsible for your own taxes
- You are not entitled to employee benefits
- This relationship does not create an agency or partnership

--------------------------------------------------------------------------------
6. PAYMENT TERMS
--------------------------------------------------------------------------------

- Payments are calculated based on distance, time, and service type
- Toro Driver deducts a platform fee from each fare
- Payments are processed weekly via direct deposit
- Tips are 100% yours and paid out separately
- You are responsible for reporting income and paying taxes
- Disputes must be raised within 30 days

--------------------------------------------------------------------------------
7. VEHICLE AND INSURANCE REQUIREMENTS
--------------------------------------------------------------------------------

You must maintain:
- A vehicle no older than 10 years (varies by service type)
- Valid vehicle registration and inspection
- Auto insurance meeting or exceeding state minimums
- Commercial insurance if required in your jurisdiction
- All required permits and licenses

--------------------------------------------------------------------------------
8. DEACTIVATION
--------------------------------------------------------------------------------

Toro Driver may deactivate your account for:
- Violation of these Terms or community guidelines
- Low ratings that fall below acceptable thresholds
- Safety concerns or complaints
- Failed background or driving record checks
- Fraudulent activity or dishonesty
- Inactivity for extended periods

--------------------------------------------------------------------------------
9. LIMITATION OF LIABILITY
--------------------------------------------------------------------------------

TO THE MAXIMUM EXTENT PERMITTED BY LAW:
- Toro Driver is not liable for actions between Drivers and riders
- Toro Driver is not liable for indirect or consequential damages
- Total liability shall not exceed fees paid in the past 12 months
- You agree to indemnify Toro Driver against third-party claims

--------------------------------------------------------------------------------
10. DISPUTE RESOLUTION
--------------------------------------------------------------------------------

- Disputes shall be resolved through binding arbitration
- Class action lawsuits are waived
- Disputes must be brought within one year
- You may opt out of arbitration within 30 days of registration

--------------------------------------------------------------------------------
11. GOVERNING LAW
--------------------------------------------------------------------------------

These Terms shall be governed by the laws of the State of California, USA,
without regard to conflict of law principles.

--------------------------------------------------------------------------------
12. CONTACT INFORMATION
--------------------------------------------------------------------------------

For questions about these Terms, contact us at:
Email: legal@torodriver.com
Driver Support: driversupport@torodriver.com
Address: Los Angeles, California, USA

================================================================================
END OF TERMS AND CONDITIONS
================================================================================
''';

  static const String privacyPolicy = '''
================================================================================
TORO DRIVER - PRIVACY POLICY
Version 1.0 | Effective Date: January 2025
================================================================================

Your privacy is critically important to us. This Privacy Policy explains how
Toro Driver ("we," "our," or "us") collects, uses, and protects your personal
information as a Driver on our platform.

--------------------------------------------------------------------------------
1. INFORMATION WE COLLECT
--------------------------------------------------------------------------------

A. INFORMATION YOU PROVIDE:
- Account information (name, email, phone number, address)
- Identity documents (driver's license, photo ID)
- Vehicle information (make, model, year, registration, insurance)
- Payment information (bank account for deposits)
- Background check consent and information
- Profile photo

B. INFORMATION COLLECTED AUTOMATICALLY:
- Location data (GPS tracking during active rides)
- Trip data (routes, duration, distance)
- Device information (model, OS, unique identifiers)
- App usage data and interaction patterns
- Vehicle telematics (if enabled)

C. INFORMATION FROM THIRD PARTIES:
- Background check results
- Driving record information
- Insurance verification
- Identity verification results

--------------------------------------------------------------------------------
2. HOW WE USE YOUR INFORMATION
--------------------------------------------------------------------------------

We use your information to:
- Verify your identity and eligibility
- Connect you with riders seeking services
- Process payments and tax documentation
- Ensure safety and security of our platform
- Improve our services and app experience
- Communicate important updates
- Comply with legal and regulatory requirements
- Investigate incidents and resolve disputes

--------------------------------------------------------------------------------
3. LOCATION DATA
--------------------------------------------------------------------------------

We collect precise location data to:
- Match you with nearby ride requests
- Provide navigation and routing
- Calculate accurate fares and distances
- Ensure rider safety (share location with riders)
- Investigate incidents and disputes
- Comply with regulatory requirements

Location is tracked when you are online/available.
You can go offline to stop location tracking.

--------------------------------------------------------------------------------
4. DATA SHARING AND DISCLOSURE
--------------------------------------------------------------------------------

We may share your information with:

A. RIDERS:
- First name and profile photo
- Vehicle information (make, model, color, plate)
- Real-time location during rides
- Rating and review history

B. SERVICE PROVIDERS:
- Background check companies
- Payment processors
- Insurance verification services
- Cloud hosting providers
- Analytics and support tools

C. LEGAL REQUIREMENTS:
- When required by law, subpoena, or court order
- To protect rights, safety, or property
- To investigate potential violations

D. BUSINESS TRANSFERS:
- In connection with merger, acquisition, or sale

WE DO NOT SELL YOUR PERSONAL INFORMATION.

--------------------------------------------------------------------------------
5. DATA SECURITY
--------------------------------------------------------------------------------

We implement industry-standard security measures:
- Encryption of data in transit and at rest
- Regular security audits and testing
- Access controls and authentication
- Employee training on data protection
- Incident response procedures

--------------------------------------------------------------------------------
6. DATA RETENTION
--------------------------------------------------------------------------------

We retain your data for:
- Active accounts: As long as you remain active
- Trip records: 7 years for tax and legal compliance
- Background check data: As required by law
- After deactivation: 90 days, then anonymized/deleted

--------------------------------------------------------------------------------
7. YOUR RIGHTS
--------------------------------------------------------------------------------

You have the right to:
- ACCESS: Request a copy of your personal data
- CORRECT: Update inaccurate information
- DELETE: Request deletion of your account and data
- OPT-OUT: Control marketing communications
- PORTABILITY: Receive your data in portable format
- RESTRICT: Limit how we process your data

To exercise these rights, contact privacy@torodriver.com

--------------------------------------------------------------------------------
8. CALIFORNIA PRIVACY RIGHTS (CCPA)
--------------------------------------------------------------------------------

California residents have additional rights:
- Right to know what personal information is collected
- Right to delete personal information
- Right to opt-out of sale of personal information
- Right to non-discrimination for exercising privacy rights

--------------------------------------------------------------------------------
9. CONTACT US
--------------------------------------------------------------------------------

For privacy-related inquiries:
Email: privacy@torodriver.com
Driver Support: driversupport@torodriver.com
Address: Los Angeles, California, USA

================================================================================
END OF PRIVACY POLICY
================================================================================
''';

  static const String driverAgreement = '''
================================================================================
TORO DRIVER - INDEPENDENT CONTRACTOR AGREEMENT
Version 1.0 | Effective Date: January 2025
================================================================================

This Independent Contractor Agreement ("Agreement") is between you ("Driver,"
"Contractor," or "you") and Toro Driver LLC ("Company," "we," or "us").

--------------------------------------------------------------------------------
1. INDEPENDENT CONTRACTOR RELATIONSHIP
--------------------------------------------------------------------------------

A. STATUS:
You are an independent contractor, NOT an employee of Toro Driver. Nothing in
this Agreement creates an employment, agency, joint venture, or partnership
relationship.

B. CONTROL:
You retain complete control over:
- When you choose to be available on the platform
- Whether to accept or decline any service request
- The manner in which you provide services
- Your work schedule and hours
- Use of other platforms or services

C. NO EXCLUSIVITY:
You are free to provide services through other platforms, apps, or businesses
at any time, including while using the Toro Driver platform.

--------------------------------------------------------------------------------
2. SERVICE REQUIREMENTS
--------------------------------------------------------------------------------

When providing services through the platform, you agree to:
- Provide safe, professional transportation
- Follow all applicable traffic laws
- Maintain your vehicle in safe condition
- Not operate while impaired by drugs or alcohol
- Treat all riders with respect and courtesy
- Complete accepted trips unless safety concerns arise

--------------------------------------------------------------------------------
3. VEHICLE AND EQUIPMENT
--------------------------------------------------------------------------------

You are responsible for providing and maintaining:
- A qualifying vehicle that meets our standards
- Valid registration and inspection
- Adequate auto insurance coverage
- Any necessary permits or licenses
- A compatible smartphone device
- All fuel, maintenance, and repair costs

--------------------------------------------------------------------------------
4. BACKGROUND CHECK AND SCREENING
--------------------------------------------------------------------------------

You consent to and must pass:
- Criminal background check
- Motor vehicle record check
- Identity verification
- Insurance verification
- Ongoing periodic re-screening

--------------------------------------------------------------------------------
5. PAYMENT AND FEES
--------------------------------------------------------------------------------

A. FARE CALCULATION:
Fares are calculated by the platform based on distance, time, and service type.
The platform retains a service fee from each fare.

B. PAYMENT SCHEDULE:
Payments are processed weekly via direct deposit to your designated account.
Express pay options may be available for a fee.

C. TAXES:
You are responsible for all applicable taxes. You will receive a 1099 form
if you earn above the IRS threshold.

--------------------------------------------------------------------------------
6. INSURANCE REQUIREMENTS
--------------------------------------------------------------------------------

You must maintain auto insurance that meets or exceeds:
- State minimum liability coverage
- Any additional coverage required by local regulations
- Commercial coverage if required in your jurisdiction

Toro Driver provides contingent liability coverage that applies during active
trips when your personal insurance does not cover rideshare activities.

--------------------------------------------------------------------------------
7. CONFIDENTIALITY
--------------------------------------------------------------------------------

You agree not to disclose confidential information including:
- Rider personal information
- Platform pricing algorithms
- Business strategies and plans
- Technical or trade secrets

--------------------------------------------------------------------------------
8. TERMINATION
--------------------------------------------------------------------------------

Either party may terminate this Agreement at any time for any reason.
Toro Driver may deactivate your account immediately for safety violations,
fraudulent activity, or material breach of this Agreement.

--------------------------------------------------------------------------------
9. DISPUTE RESOLUTION
--------------------------------------------------------------------------------

All disputes arising from this Agreement shall be resolved through binding
arbitration in accordance with the Terms and Conditions.

--------------------------------------------------------------------------------
10. ACKNOWLEDGMENT
--------------------------------------------------------------------------------

By accepting this Agreement, you acknowledge that:
- You have read and understood all terms
- You are voluntarily entering into this Agreement
- You understand your independent contractor status
- You waive any claims to employee benefits
- You are responsible for your own taxes and expenses

================================================================================
END OF INDEPENDENT CONTRACTOR AGREEMENT
================================================================================
''';

  static const String liabilityWaiver = '''
================================================================================
TORO DRIVER - LIABILITY WAIVER AND RELEASE
Version 1.0 | Effective Date: January 2025
================================================================================

PLEASE READ CAREFULLY - THIS AFFECTS YOUR LEGAL RIGHTS

By using the Toro Driver platform as a Driver, you agree to the following
waiver and release of liability.

--------------------------------------------------------------------------------
1. ASSUMPTION OF RISK
--------------------------------------------------------------------------------

You acknowledge and understand that:
- Driving involves inherent risks including accidents and injuries
- You may encounter difficult or dangerous situations
- Weather, traffic, and road conditions create risks
- Interactions with riders may present risks
- You voluntarily assume all such risks

--------------------------------------------------------------------------------
2. RELEASE OF LIABILITY
--------------------------------------------------------------------------------

To the fullest extent permitted by law, you release and discharge Toro Driver,
its officers, directors, employees, agents, and affiliates from any and all
claims, demands, damages, costs, expenses, and causes of action arising from:

- Your use of the platform or provision of services
- Accidents, injuries, or property damage
- Interactions with riders or third parties
- Lost income or business opportunities
- Any other loss or damage of any kind

--------------------------------------------------------------------------------
3. INDEMNIFICATION
--------------------------------------------------------------------------------

You agree to indemnify, defend, and hold harmless Toro Driver from any claims,
damages, losses, and expenses (including legal fees) arising from:

- Your breach of any terms or agreements
- Your negligent or wrongful acts
- Your violation of any law or regulation
- Any claim by a third party related to your services
- Your failure to maintain adequate insurance

--------------------------------------------------------------------------------
4. LIMITATION OF DAMAGES
--------------------------------------------------------------------------------

IN NO EVENT SHALL TORO DRIVER BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL,
CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO LOST PROFITS,
LOST DATA, OR BUSINESS INTERRUPTION.

--------------------------------------------------------------------------------
5. ACKNOWLEDGMENT
--------------------------------------------------------------------------------

I HAVE READ THIS WAIVER AND RELEASE, FULLY UNDERSTAND ITS TERMS, AND SIGN IT
FREELY AND VOLUNTARILY. I UNDERSTAND THAT I AM GIVING UP SUBSTANTIAL RIGHTS,
INCLUDING THE RIGHT TO SUE.

================================================================================
END OF LIABILITY WAIVER
================================================================================
''';

  /// Combined document for quick display
  static String get combinedLegalDocument => '''
$termsAndConditions

$privacyPolicy

$driverAgreement

$liabilityWaiver
''';
}
