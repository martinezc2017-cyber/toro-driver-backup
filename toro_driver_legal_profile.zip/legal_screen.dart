import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../core/logging/app_logger.dart';
import '../core/legal/legal_documents.dart';

class LegalScreen extends StatefulWidget {
  const LegalScreen({super.key});

  @override
  State<LegalScreen> createState() => _LegalScreenState();
}

class _LegalScreenState extends State<LegalScreen>
    with TickerProviderStateMixin {
  late AnimationController _sparkleController;
  late AnimationController _pulseController;

  // Theme colors for Toro Driver
  static const Color primaryColor = Color(0xFF1E88E5); // Blue
  static const Color secondaryColor = Color(0xFF43A047); // Green
  static const Color backgroundColor = Color(0xFFF5F5F5);

  @override
  void initState() {
    super.initState();
    AppLogger.log('OPEN -> LegalScreen');

    _sparkleController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat();

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _sparkleController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  /// Show legal document with LOCKED theme (always high contrast black on white)
  void _showDocument(BuildContext context, String title, String content) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.9,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (_, controller) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade400,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              // Title header
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border(
                    bottom: BorderSide(
                      color: Colors.grey.shade200,
                      width: 1,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: primaryColor,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: primaryColor.withValues(alpha: 0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: const Icon(Icons.gavel, color: Colors.white, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                              letterSpacing: 0.3,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Row(
                            children: [
                              Icon(Icons.lock, size: 12, color: Colors.grey.shade600),
                              const SizedBox(width: 4),
                              Text(
                                'Documento legal protegido',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(ctx),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: Icon(Icons.close, size: 20, color: Colors.grey.shade700),
                      ),
                    ),
                  ],
                ),
              ),
              // Document content
              Expanded(
                child: Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: Colors.grey.shade300,
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: ListView(
                    controller: controller,
                    children: [
                      SelectableText(
                        content,
                        style: const TextStyle(
                          fontSize: 14,
                          height: 1.7,
                          fontFamily: 'monospace',
                          color: Colors.black87,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.2,
                        ),
                      ),
                      const SizedBox(height: 30),
                      // Footer with lock indicator
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.grey.shade200),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.verified_user, size: 18, color: Colors.green.shade600),
                            const SizedBox(width: 8),
                            Text(
                              'Este documento tiene visibilidad protegida',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade700,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: primaryColor.withValues(alpha: 0.2),
                  blurRadius: 8,
                ),
              ],
            ),
            child: const Icon(Icons.arrow_back, color: primaryColor, size: 20),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [primaryColor, secondaryColor],
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.gavel, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              'Legal',
              style: TextStyle(
                color: theme.colorScheme.onSurface,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        actions: [
          AnimatedBuilder(
            animation: _sparkleController,
            builder: (context, child) {
              return Transform.rotate(
                angle: _sparkleController.value * 2 * math.pi,
                child: const Icon(
                  Icons.auto_awesome,
                  color: primaryColor,
                  size: 20,
                ),
              );
            },
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: Stack(
        children: [
          // Floating decorations
          ..._buildFloatingDecorations(),

          // Main content
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 8),

                  // Terms and Conditions Button
                  _buildLegalButton(
                    context: context,
                    icon: Icons.description_outlined,
                    iconColor: Colors.blue,
                    title: 'Terminos y Condiciones',
                    subtitle: 'Reglas de uso del servicio',
                    onTap: () => _showDocument(
                      context,
                      'Terminos y Condiciones',
                      LegalDocuments.termsAndConditions,
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Privacy Policy Button
                  _buildLegalButton(
                    context: context,
                    icon: Icons.privacy_tip_outlined,
                    iconColor: Colors.green,
                    title: 'Politica de Privacidad',
                    subtitle: 'Como protegemos tus datos',
                    onTap: () => _showDocument(
                      context,
                      'Politica de Privacidad',
                      LegalDocuments.privacyPolicy,
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Driver Agreement Button
                  _buildLegalButton(
                    context: context,
                    icon: Icons.handshake_outlined,
                    iconColor: Colors.orange,
                    title: 'Acuerdo del Conductor',
                    subtitle: 'Contrato de contratista independiente',
                    onTap: () => _showDocument(
                      context,
                      'Acuerdo del Conductor',
                      LegalDocuments.driverAgreement,
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Liability Waiver Button
                  _buildLegalButton(
                    context: context,
                    icon: Icons.security_outlined,
                    iconColor: Colors.red,
                    title: 'Exoneracion de Responsabilidad',
                    subtitle: 'Liberacion de responsabilidad',
                    onTap: () => _showDocument(
                      context,
                      'Exoneracion de Responsabilidad',
                      LegalDocuments.liabilityWaiver,
                    ),
                  ),

                  const Spacer(),

                  // Footer
                  Center(
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                primaryColor.withValues(alpha: 0.1),
                                secondaryColor.withValues(alpha: 0.1),
                              ],
                            ),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.verified_user_outlined,
                            size: 40,
                            color: primaryColor,
                          ),
                        ),
                        const SizedBox(height: 12),
                        ShaderMask(
                          shaderCallback: (bounds) => const LinearGradient(
                            colors: [primaryColor, secondaryColor],
                          ).createShader(bounds),
                          child: const Text(
                            'Toro Driver',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Version 1.0.0',
                          style: TextStyle(
                            fontSize: 12,
                            color: theme.colorScheme.onSurface.withValues(alpha: 0.5),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '2025 Toro Driver Inc. All rights reserved.',
                          style: TextStyle(
                            fontSize: 11,
                            color: theme.colorScheme.onSurface.withValues(alpha: 0.4),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildFloatingDecorations() {
    return [
      Positioned(
        top: 80,
        left: 15,
        child: _buildAnimatedSparkle(primaryColor, 18),
      ),
      Positioned(
        top: 60,
        right: 20,
        child: _buildAnimatedStar(secondaryColor, 16),
      ),
      Positioned(
        top: 200,
        left: 10,
        child: _buildAnimatedSparkle(secondaryColor, 14),
      ),
      Positioned(
        top: 280,
        right: 15,
        child: _buildAnimatedStar(primaryColor, 12),
      ),
      Positioned(
        bottom: 150,
        left: 20,
        child: _buildAnimatedSparkle(primaryColor, 14),
      ),
      Positioned(
        bottom: 200,
        right: 25,
        child: _buildAnimatedStar(secondaryColor, 16),
      ),
    ];
  }

  Widget _buildAnimatedSparkle(Color color, double size) {
    return AnimatedBuilder(
      animation: _sparkleController,
      builder: (context, child) {
        return Transform.rotate(
          angle: _sparkleController.value * 2 * math.pi,
          child: Opacity(
            opacity: 0.3 + (_sparkleController.value * 0.3),
            child: Icon(Icons.auto_awesome, color: color, size: size),
          ),
        );
      },
    );
  }

  Widget _buildAnimatedStar(Color color, double size) {
    return AnimatedBuilder(
      animation: _sparkleController,
      builder: (context, child) {
        return Opacity(
          opacity: 0.3 + (_sparkleController.value * 0.4),
          child: Icon(Icons.star, color: color, size: size),
        );
      },
    );
  }

  Widget _buildLegalButton({
    required BuildContext context,
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: iconColor.withValues(alpha: 0.2),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: primaryColor.withValues(alpha: 0.1),
              blurRadius: 15,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Row(
          children: [
            // Icon container
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [iconColor, iconColor.withValues(alpha: 0.7)],
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: iconColor.withValues(alpha: 0.4),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 16),
            // Text content
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: theme.colorScheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 13,
                      color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                    ),
                  ),
                ],
              ),
            ),
            // Arrow
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    iconColor.withValues(alpha: 0.15),
                    iconColor.withValues(alpha: 0.05),
                  ],
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(Icons.arrow_forward_ios, color: iconColor, size: 16),
            ),
          ],
        ),
      ),
    );
  }
}
