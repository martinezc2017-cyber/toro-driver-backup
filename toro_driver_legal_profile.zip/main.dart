import 'package:flutter/material.dart';
import 'src/screens/home_screen.dart';
import 'src/screens/navigation_screen.dart';
import 'src/screens/profile_screen.dart';
import 'src/screens/history_screen.dart';
import 'src/screens/settings_screen.dart';
import 'src/screens/legal_screen.dart';
import 'src/screens/terms_acceptance_screen.dart';
import 'src/screens/account_screen.dart';

void main() {
  runApp(const ToroDriverApp());
}

class ToroDriverApp extends StatelessWidget {
  const ToroDriverApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Toro Driver',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1E88E5),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1E88E5),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      themeMode: ThemeMode.system,
      initialRoute: '/terms',
      routes: {
        '/': (context) => const HomeScreen(),
        '/terms': (context) => const TermsAcceptanceScreen(),
        '/navigation': (context) => const NavigationScreen(),
        '/profile': (context) => const ProfileScreen(),
        '/history': (context) => const HistoryScreen(),
        '/settings': (context) => const SettingsScreen(),
        '/legal': (context) => const LegalScreen(),
        '/account': (context) => const AccountScreen(),
        // Placeholder routes - to be implemented
        '/earnings': (context) => _buildPlaceholderScreen('Ganancias', Icons.account_balance_wallet),
        '/vehicle': (context) => _buildPlaceholderScreen('Mi Vehiculo', Icons.directions_car),
        '/support': (context) => _buildPlaceholderScreen('Soporte', Icons.support_agent),
        '/documents': (context) => _buildPlaceholderScreen('Documentos', Icons.description),
        '/ranking': (context) => _buildPlaceholderScreen('Ranking', Icons.star_rate),
        '/refer': (context) => _buildPlaceholderScreen('Referir Amigos', Icons.card_giftcard),
        '/language': (context) => _buildPlaceholderScreen('Idioma', Icons.language),
        '/logout': (context) => _buildLogoutScreen(context),
      },
    );
  }

  Widget _buildPlaceholderScreen(String title, IconData icon) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF1E88E5), Color(0xFF43A047)],
                ),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF1E88E5).withValues(alpha: 0.3),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Icon(icon, size: 48, color: Colors.white),
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Proximamente...',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLogoutScreen(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.logout,
                size: 48,
                color: Colors.red.shade600,
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Cerrar Sesion?',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Estas seguro que deseas salir?',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancelar'),
                ),
                const SizedBox(width: 16),
                FilledButton(
                  onPressed: () {
                    Navigator.pushNamedAndRemoveUntil(
                      context,
                      '/terms',
                      (route) => false,
                    );
                  },
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.red,
                  ),
                  child: const Text('Salir'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
