import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../core/logging/app_logger.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with TickerProviderStateMixin {
  final String _driverName = 'Juan Conductor';
  late AnimationController _sparkleController;

  // Theme colors for Toro Driver
  static const Color primaryColor = Color(0xFF1E88E5); // Blue
  static const Color secondaryColor = Color(0xFF43A047); // Green
  static const Color backgroundColor = Color(0xFFF5F5F5);

  @override
  void initState() {
    super.initState();
    AppLogger.log('OPEN -> ProfileScreen');
    _sparkleController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat();
  }

  @override
  void dispose() {
    _sparkleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: backgroundColor,
      body: SafeArea(
        child: Stack(
          children: [
            // Floating decorations
            ..._buildFloatingDecorations(),

            // Main content
            SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // Header
                  _buildHeader(theme),
                  const SizedBox(height: 20),

                  // Avatar
                  _buildAvatar(),
                  const SizedBox(height: 16),

                  // Name and rating display
                  Text(
                    _driverName,
                    style: theme.textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                    ),
                  ),
                  const SizedBox(height: 8),

                  // Driver Rating
                  _buildRatingBadge(),
                  const SizedBox(height: 28),

                  // Stats card
                  _buildStatsCard(theme),
                  const SizedBox(height: 20),

                  // Menu items
                  _buildMenuCard(theme),
                  const SizedBox(height: 100),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildFloatingDecorations() {
    return [
      Positioned(
        top: 60,
        left: 20,
        child: _buildAnimatedSparkle(primaryColor, 20),
      ),
      Positioned(
        top: 40,
        right: 30,
        child: _buildAnimatedStar(secondaryColor, 18),
      ),
      Positioned(
        top: 200,
        left: 10,
        child: _buildAnimatedSparkle(secondaryColor, 14),
      ),
      Positioned(
        top: 280,
        right: 15,
        child: _buildAnimatedStar(primaryColor, 16),
      ),
    ];
  }

  Widget _buildAnimatedSparkle(Color color, double size) {
    return AnimatedBuilder(
      animation: _sparkleController,
      builder: (context, child) {
        return Transform.rotate(
          angle: _sparkleController.value * 2 * math.pi,
          child: Icon(
            Icons.auto_awesome,
            color: color.withValues(alpha: 0.6),
            size: size,
          ),
        );
      },
    );
  }

  Widget _buildAnimatedStar(Color color, double size) {
    return AnimatedBuilder(
      animation: _sparkleController,
      builder: (context, child) {
        final opacity = 0.3 + (math.sin(_sparkleController.value * 4 * math.pi) * 0.3);
        return Icon(
          Icons.star,
          color: color.withValues(alpha: opacity),
          size: size,
        );
      },
    );
  }

  Widget _buildHeader(ThemeData theme) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [primaryColor, secondaryColor],
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: primaryColor.withValues(alpha: 0.4),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: const Icon(Icons.person, color: Colors.white, size: 20),
        ),
        const SizedBox(width: 12),
        Text(
          'Perfil del Conductor',
          style: theme.textTheme.headlineMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const Spacer(),
        const Icon(
          Icons.auto_awesome,
          color: primaryColor,
          size: 24,
        ),
      ],
    );
  }

  Widget _buildAvatar() {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 140,
          height: 140,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                primaryColor.withValues(alpha: 0.3),
                secondaryColor.withValues(alpha: 0.3),
              ],
            ),
          ),
        ),
        Container(
          width: 120,
          height: 120,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [primaryColor, secondaryColor],
            ),
            boxShadow: [
              BoxShadow(
                color: primaryColor.withValues(alpha: 0.5),
                blurRadius: 15,
                spreadRadius: 2,
              ),
            ],
          ),
          padding: const EdgeInsets.all(4),
          child: CircleAvatar(
            radius: 56,
            backgroundColor: Colors.white,
            child: Text(
              _driverName.isNotEmpty ? _driverName[0].toUpperCase() : 'D',
              style: const TextStyle(
                fontSize: 42,
                fontWeight: FontWeight.bold,
                color: primaryColor,
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 5,
          right: 5,
          child: GestureDetector(
            onTap: () {
              AppLogger.log('PROFILE -> Edit photo tapped');
            },
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [primaryColor, secondaryColor],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withValues(alpha: 0.4),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(Icons.camera_alt, color: Colors.white, size: 18),
            ),
          ),
        ),
        // Decorations
        const Positioned(
          top: 0,
          left: 20,
          child: Icon(Icons.star, color: primaryColor, size: 16),
        ),
        const Positioned(
          top: 10,
          right: 15,
          child: Icon(Icons.auto_awesome, color: secondaryColor, size: 14),
        ),
      ],
    );
  }

  Widget _buildRatingBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.amber.shade600,
            Colors.amber.shade400,
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.amber.withValues(alpha: 0.4),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.star, color: Colors.white, size: 20),
          const SizedBox(width: 6),
          const Text(
            '4.92',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Text(
              'Excelente',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsCard(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withValues(alpha: 0.15),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.analytics, color: primaryColor, size: 22),
              const SizedBox(width: 10),
              Text(
                'Estadisticas',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem(Icons.drive_eta, '1,234', 'Viajes'),
              _buildStatItem(Icons.attach_money, '\$12,450', 'Ganancias'),
              _buildStatItem(Icons.timer, '892h', 'Horas'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(IconData icon, String value, String label) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                primaryColor.withValues(alpha: 0.1),
                secondaryColor.withValues(alpha: 0.1),
              ],
            ),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: primaryColor, size: 24),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: primaryColor,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade600,
          ),
        ),
      ],
    );
  }

  Widget _buildMenuCard(ThemeData theme) {
    final menuItems = [
      {'icon': Icons.account_circle, 'label': 'Cuenta', 'route': '/account', 'color': Colors.blue},
      {'icon': Icons.settings, 'label': 'Ajustes', 'route': '/settings', 'color': Colors.blueGrey},
      {'icon': Icons.history, 'label': 'Historial', 'route': '/history', 'color': Colors.cyan},
      {'icon': Icons.account_balance_wallet, 'label': 'Ganancias', 'route': '/earnings', 'color': Colors.green},
      {'icon': Icons.directions_car, 'label': 'Vehiculo', 'route': '/vehicle', 'color': Colors.orange},
      {'icon': Icons.support_agent, 'label': 'Soporte', 'route': '/support', 'color': Colors.indigo},
      {'icon': Icons.gavel, 'label': 'Legal', 'route': '/legal', 'color': Colors.purple},
      {'icon': Icons.description, 'label': 'Documentos', 'route': '/documents', 'color': Colors.teal},
      {'icon': Icons.star_rate, 'label': 'Ranking', 'route': '/ranking', 'color': Colors.amber},
      {'icon': Icons.card_giftcard, 'label': 'Referir', 'route': '/refer', 'color': Colors.pink},
      {'icon': Icons.language, 'label': 'Idioma', 'route': '/language', 'color': Colors.brown},
      {'icon': Icons.logout, 'label': 'Salir', 'route': '/logout', 'color': Colors.red},
    ];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withValues(alpha: 0.15),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.menu, color: primaryColor, size: 22),
              const SizedBox(width: 10),
              Text(
                'Menu',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              Icon(Icons.chevron_right, color: secondaryColor, size: 20),
            ],
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: menuItems.map((item) {
              return _buildMenuItem(
                icon: item['icon'] as IconData,
                label: item['label'] as String,
                route: item['route'] as String,
                color: item['color'] as Color,
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String label,
    required String route,
    required Color color,
  }) {
    return GestureDetector(
      onTap: () {
        AppLogger.log('PROFILE -> Navigate to $route');
        Navigator.pushNamed(context, route);
      },
      child: Container(
        width: 95,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              color.withValues(alpha: 0.15),
              color.withValues(alpha: 0.05),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: color.withValues(alpha: 0.3),
            width: 1.5,
          ),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [color, color.withValues(alpha: 0.7)],
                ),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: color.withValues(alpha: 0.4),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 20),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: color.withValues(alpha: 0.9),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
